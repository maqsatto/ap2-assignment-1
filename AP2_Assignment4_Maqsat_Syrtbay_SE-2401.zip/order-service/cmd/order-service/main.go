package main

import (
	"context"
	"database/sql"
	"fmt"
	"log"
	"net"
	"net/http"
	"os"
	"os/signal"
	"strconv"
	"syscall"
	"time"

	"order-service/internal/repository"
	grpc_transport "order-service/internal/transport/grpc"
	ordhttp "order-service/internal/transport/http"
	"order-service/internal/usecase"

	"github.com/gin-gonic/gin"
	_ "github.com/lib/pq"
	"github.com/redis/go-redis/v9"
	"google.golang.org/grpc"
)

func main() {
	dbURL := getEnv("ORDER_DB_URL", "postgres://postgres:postgres@localhost:5432/order_db?sslmode=disable")
	paymentGRPCAddr := getEnv("PAYMENT_GRPC_ADDR", "localhost:50051")
	orderGRPCPort := getEnv("ORDER_GRPC_PORT", "50052")
	redisAddr := getEnv("REDIS_ADDR", "localhost:6379")
	cacheTTL := getEnvDuration("ORDER_CACHE_TTL", 5*time.Minute)
	rateLimit := getEnvInt64("RATE_LIMIT_REQUESTS", 10)
	rateWindow := getEnvDuration("RATE_LIMIT_WINDOW", time.Minute)

	db, err := sql.Open("postgres", dbURL)
	if err != nil {
		log.Fatalf("failed to connect to database: %v", err)
	}
	defer db.Close()

	if err := db.Ping(); err != nil {
		log.Fatalf("failed to ping database: %v", err)
	}

	repo, err := repository.NewOrderRepo(db)
	if err != nil {
		log.Fatalf("failed to initialize order repository: %v", err)
	}

	// Create gRPC payment client
	paymentClient, err := usecase.NewPaymentGRPCClient(paymentGRPCAddr)
	if err != nil {
		log.Fatalf("failed to create payment gRPC client: %v", err)
	}
	defer paymentClient.Close()

	uc := usecase.NewOrderUseCase(repo, paymentClient)
	redisClient := redis.NewClient(&redis.Options{Addr: redisAddr})
	defer redisClient.Close()
	uc.SetCache(repository.NewRedisOrderCache(redisClient), cacheTTL)
	handler := ordhttp.NewHandler(uc)

	grpcServer, grpcListener := newGRPCServer(orderGRPCPort, repo)
	go func() {
		log.Printf("Order gRPC Server running on :%s", orderGRPCPort)
		if err := grpcServer.Serve(grpcListener); err != nil {
			log.Printf("order gRPC server stopped: %v", err)
		}
	}()

	// Start HTTP server
	r := gin.Default()
	r.Use(ordhttp.RedisRateLimiter(redisClient, rateLimit, rateWindow))

	r.POST("/orders", handler.CreateOrder)
	r.GET("/orders", handler.ListOrders)
	r.GET("/orders/:id", handler.GetOrder)
	r.PATCH("/orders/:id/cancel", handler.CancelOrder)

	httpServer := &http.Server{Addr: ":8080", Handler: r}
	go func() {
		log.Printf("Order Service running on :8080 (db=%s, payment_grpc=%s, order_grpc=%s)", dbURL, paymentGRPCAddr, orderGRPCPort)
		if err := httpServer.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatalf("failed to start server: %v", err)
		}
	}()

	ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer stop()
	<-ctx.Done()

	log.Println("Shutting down Order Service...")
	shutdownCtx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	if err := httpServer.Shutdown(shutdownCtx); err != nil {
		log.Printf("order HTTP shutdown error: %v", err)
	}
	grpcServer.GracefulStop()
}

func newGRPCServer(port string, repo *repository.OrderRepo) (*grpc.Server, net.Listener) {
	lis, err := net.Listen("tcp", fmt.Sprintf(":%s", port))
	if err != nil {
		log.Fatalf("failed to listen on port %s: %v", port, err)
	}

	grpcServer := grpc.NewServer()

	grpc_transport.RegisterOrderServer(grpcServer, repo)

	return grpcServer, lis
}

func getEnv(key, fallback string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return fallback
}

func getEnvDuration(key string, fallback time.Duration) time.Duration {
	value := os.Getenv(key)
	if value == "" {
		return fallback
	}
	parsed, err := time.ParseDuration(value)
	if err != nil {
		return fallback
	}
	return parsed
}

func getEnvInt64(key string, fallback int64) int64 {
	value := os.Getenv(key)
	if value == "" {
		return fallback
	}
	parsed, err := strconv.ParseInt(value, 10, 64)
	if err != nil || parsed <= 0 {
		return fallback
	}
	return parsed
}
