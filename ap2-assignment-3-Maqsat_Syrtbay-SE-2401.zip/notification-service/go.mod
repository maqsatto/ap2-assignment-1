module notification-service

go 1.26.1

require github.com/rabbitmq/amqp091-go v1.10.0
